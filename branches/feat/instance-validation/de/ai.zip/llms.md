# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Änderungshistorie](changes.md)
* [CodeSystems](code-systems.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [Beispiele](examples.md)
* [ValueSets](value-sets.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [CapabilityStatements](capability-statements.md)
* [Artefaktübersicht](artifacts.md)
* [Metadaten-Übersicht](metadata.md)
* [Operationen](operations.md)
* [UML-Diagramme](uml-diagrams.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Downloads](downloads.md)
* [Anleitung](guidance.md)
* [Extensions](extensions.md)
* [Profile](profiles.md)
* [Versionierung](version-history.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [](validate.md)
* [Logische Modelle](logical-models.md)
* [Suchparameter](search-parameters.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

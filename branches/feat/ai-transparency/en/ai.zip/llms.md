# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Downloads](downloads.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Operations](operations.md)
* [Search Parameters](search-parameters.md)
* [UML Diagrams](uml-diagrams.md)
* [Extensions](extensions.md)
* [Guidance](guidance.md)
* [Value Sets](value-sets.md)
* [Capability Statements](capability-statements.md)
* [Code Systems](code-systems.md)
* [Security and Privacy](security-and-privacy.md)
* [Translation Information](translationinfo.md)
* [Metadata Overview](metadata.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Changelog](changes.md)
* [Logical Models](logical-models.md)
* [Versioning](version-history.md)
* [Guidance for Researchers](researcher-guidance.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

# Operationen - MII Implementation Guide Module Template v2027.0.0-draft.1

* [**Inhaltsverzeichnis**](toc.md)
* **Operationen**

## Operationen

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

> **Optionale Seite (0..1).** Das KDS-Modulmenü führt diese Seite als **optional**. Entscheiden Sie für Ihr Modul: Seite **behalten** — Inhalte ausfüllen und dieses Banner samt `OPTIONAL-PAGE`-Marker-Kommentar löschen (in dieser Datei UND in der englischen Quellseite) — oder Seite **entfernen**, nach der Schritt-für-Schritt-Anleitung in [`docs/optional-pages.md`](https://github.com/medizininformatik-initiative/mii-kds-module-template/blob/main/docs/optional-pages.md) dieses Repositories. Ein Release darf dieses Banner nicht enthalten (Konventions-Check M9).

### Operationen

Diese Seite listet die FHIR-Operationen, die das Modul **Module Template** definiert (Namenskonvention `MII_OD_<Modul>_<Name>`), sofern definiert.

> [TODO: Listen Sie die Operationen mit ihren Aufruf-Kontexten auf — oder entfernen Sie diese Seite, wenn Ihr Modul keine definiert.]


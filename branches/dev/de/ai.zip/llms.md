# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [CodeSystems](code-systems.md)
* [Versionierung](version-history.md)
* [Downloads](downloads.md)
* [ValueSets](value-sets.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [Metadaten-Übersicht](metadata.md)
* [UML-Diagramme](uml-diagrams.md)
* [Artefaktübersicht](artifacts.md)
* [Extensions](extensions.md)
* [Änderungshistorie](changes.md)
* [Operationen](operations.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Suchparameter](search-parameters.md)
* [Anleitung](guidance.md)
* [CapabilityStatements](capability-statements.md)
* [Logische Modelle](logical-models.md)
* [Profile](profiles.md)
* [Beispiele](examples.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Search Parameters](search-parameters.md)
* [Code Systems](code-systems.md)
* [Guidance](guidance.md)
* [Examples](examples.md)
* [Translation Information](translationinfo.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Downloads](downloads.md)
* [Operations](operations.md)
* [Artifacts Summary](artifacts.md)
* [Logical Models](logical-models.md)
* [](validate.md)
* [Profiles](profiles.md)
* [Versioning](version-history.md)
* [Extensions](extensions.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Metadata Overview](metadata.md)
* [UML Diagrams](uml-diagrams.md)
* [Security and Privacy](security-and-privacy.md)
* [Changelog](changes.md)
* [Capability Statements](capability-statements.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Value Sets](value-sets.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Translation Information](translationinfo.md)
* [Code Systems](code-systems.md)
* [Versioning](version-history.md)
* [Downloads](downloads.md)
* [Value Sets](value-sets.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Metadata Overview](metadata.md)
* [UML Diagrams](uml-diagrams.md)
* [Artifacts Summary](artifacts.md)
* [Extensions](extensions.md)
* [Changelog](changes.md)
* [Operations](operations.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Security and Privacy](security-and-privacy.md)
* [Search Parameters](search-parameters.md)
* [Guidance](guidance.md)
* [Capability Statements](capability-statements.md)
* [Logical Models](logical-models.md)
* [Profiles](profiles.md)
* [Examples](examples.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

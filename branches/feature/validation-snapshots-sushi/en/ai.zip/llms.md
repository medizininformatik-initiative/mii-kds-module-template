# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Downloads](downloads.md)
* [Capability Statements](capability-statements.md)
* [Metadata Overview](metadata.md)
* [Security and Privacy](security-and-privacy.md)
* [Changelog](changes.md)
* [Logical Models](logical-models.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Guidance](guidance.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Artifacts Summary](artifacts.md)
* [UML Diagrams](uml-diagrams.md)
* [Versioning](version-history.md)
* [Profiles](profiles.md)
* [Translation Information](translationinfo.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Extensions](extensions.md)
* [Search Parameters](search-parameters.md)
* [Examples](examples.md)
* [Operations](operations.md)
* [Value Sets](value-sets.md)
* [Code Systems](code-systems.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Value Sets](value-sets.md)
* [Profiles](profiles.md)
* [UML Diagrams](uml-diagrams.md)
* [Code Systems](code-systems.md)
* [Translation Information](translationinfo.md)
* [Capability Statements](capability-statements.md)
* [Artifacts Summary](artifacts.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Metadata Overview](metadata.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Guidance](guidance.md)
* [Extensions](extensions.md)
* [Versioning](version-history.md)
* [Security and Privacy](security-and-privacy.md)
* [Changelog](changes.md)
* [Operations](operations.md)
* [Logical Models](logical-models.md)
* [Search Parameters](search-parameters.md)
* [Downloads](downloads.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

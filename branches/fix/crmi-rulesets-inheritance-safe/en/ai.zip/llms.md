# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Security and Privacy](security-and-privacy.md)
* [Changelog](changes.md)
* [Code Systems](code-systems.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Examples](examples.md)
* [Value Sets](value-sets.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Capability Statements](capability-statements.md)
* [Artifacts Summary](artifacts.md)
* [Metadata Overview](metadata.md)
* [Operations](operations.md)
* [UML Diagrams](uml-diagrams.md)
* [Translation Information](translationinfo.md)
* [Downloads](downloads.md)
* [Guidance](guidance.md)
* [Extensions](extensions.md)
* [Profiles](profiles.md)
* [Versioning](version-history.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Logical Models](logical-models.md)
* [Search Parameters](search-parameters.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

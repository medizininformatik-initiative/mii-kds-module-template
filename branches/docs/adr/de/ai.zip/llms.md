# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Suchparameter](search-parameters.md)
* [CodeSystems](code-systems.md)
* [Anleitung](guidance.md)
* [Beispiele](examples.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Downloads](downloads.md)
* [Operationen](operations.md)
* [Artefaktübersicht](artifacts.md)
* [Logische Modelle](logical-models.md)
* [](validate.md)
* [Profile](profiles.md)
* [Versionierung](version-history.md)
* [Extensions](extensions.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Metadaten-Übersicht](metadata.md)
* [UML-Diagramme](uml-diagrams.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Änderungshistorie](changes.md)
* [CapabilityStatements](capability-statements.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [ValueSets](value-sets.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-template.0.13.0: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Beispiele](examples.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [ValueSets](value-sets.md)
* [CodeSystems](code-systems.md)
* [Versionierung](version-history.md)
* [Extensions](extensions.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Metadaten-Übersicht](metadata.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Profile](profiles.md)
* [Artefaktübersicht](artifacts.md)
* [Suchparameter](search-parameters.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Änderungshistorie](changes.md)
* [Logische Modelle](logical-models.md)
* [Operationen](operations.md)
* [Anleitung](guidance.md)
* [Downloads](downloads.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [CapabilityStatements](capability-statements.md)
* [UML-Diagramme](uml-diagrams.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)

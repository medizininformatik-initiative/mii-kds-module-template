# Value Sets - MII Implementation Guide Module Template v2027.0.0-template.0.14.0

* [**Table of Contents**](toc.md)
* **Value Sets**

## Value Sets

> **Optional page (0..1).** The KDS module menu lists this page as **optional**. Decide for your module: **keep** it — fill it in and delete this banner and the `OPTIONAL-PAGE` marker comment (in this file AND the German mirror) — or **remove** it, following the per-entry procedure in [`docs/optional-pages.md`](https://github.com/medizininformatik-initiative/mii-kds-module-template/blob/main/docs/optional-pages.md) of this repository. A release must not ship with this banner (convention check M9).

### Value Sets

This page describes the ValueSets of the **Module Template** module (naming convention `MII_VS_<Module>_<Name>`). For general guidance on using codes, see [FHIR Terminology](http://hl7.org/fhir/R4/terminologies.html); the code systems the sets draw from are described on the [Code Systems](code-systems.md) page.

**Expansions:** ValueSet expansions in this guide are produced by a FHIR terminology server — SU-TermServ if the client certificate is configured, otherwise the public HL7 server `tx.fhir.org` (in which case some KDS-specific ValueSets may not expand completely).

> [TODO: If your module uses SNOMED CT, state the edition/version used. List the module's own ValueSets, or refer to the automatically generated artifact list — or remove this page if your module defines none.]


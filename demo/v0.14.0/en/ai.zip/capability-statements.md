# Capability Statements - MII Implementation Guide Module Template v2027.0.0-template.0.14.0

* [**Table of Contents**](toc.md)
* **Capability Statements**

## Capability Statements

### Capability Statements

The CapabilityStatements of the **Module Template** module describe the expected server/client capabilities (supported resources and interactions).

> [TODO: Link to your module's CapabilityStatement(s), or delete this page.]


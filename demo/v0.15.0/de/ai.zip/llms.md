# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-template.0.15.0: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Beispiele](examples.md)
* [Downloads](downloads.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Operationen](operations.md)
* [Suchparameter](search-parameters.md)
* [UML-Diagramme](uml-diagrams.md)
* [Extensions](extensions.md)
* [Anleitung](guidance.md)
* [ValueSets](value-sets.md)
* [CapabilityStatements](capability-statements.md)
* [CodeSystems](code-systems.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Metadaten-Übersicht](metadata.md)
* [Profile](profiles.md)
* [Artefaktübersicht](artifacts.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [Änderungshistorie](changes.md)
* [](validate.md)
* [Logische Modelle](logical-models.md)
* [Versionierung](version-history.md)
* [Anleitung für Forschende](researcher-guidance.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
